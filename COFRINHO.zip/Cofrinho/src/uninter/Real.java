package uninter;

public class Real extends Moeda {
	
	public Real(int cambio, double valor, double converter) {
		super(cambio, valor);
		this.saldoReal = converter;
	}
	
	double saldoReal = valor;

	@Override
	double calculaValor() {
		double total = saldoReal * 1;
		// adicionar somatorio de quantidade em real aqui nesse bloc, metodo herdado classe Moeda
		return total;
	}

	@Override
	public String toString() {
		return "Real [saldoReal=" + valor + "]";
	}


	
}

	
