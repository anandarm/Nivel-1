package uninter;

import java.util.ArrayList;

public class Cofre {
		
		static ArrayList<Moeda> listaMoeda = new ArrayList<Moeda>();
		
		public void adicionar(Moeda mod) {
			listaMoeda.add(mod);

		}
		
		public void remover(Moeda mod) {
			listaMoeda.remove(mod);
			
		}

		public void listar() {
			for (Moeda m: listaMoeda) {
				System.out.println(m);
		}
		
	}

}
		

