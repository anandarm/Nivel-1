package uninter;

import java.util.Objects;

public abstract class Moeda {
	int cambio;
	double valor;

	public Moeda(int cambio, double valor) {
		super();
		this.cambio = cambio;
		this.valor = valor;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cambio, valor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moeda other = (Moeda) obj;
		return cambio == other.cambio && Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
	}


	abstract double calculaValor();
	
}
	
	

