package uninter;

public class Dolar extends Moeda{
	
	double converter;
	

	public Dolar(int cambio, double valor, double converter) {
		super(cambio, valor);
		this.converter = converter;
	}
	
	double saldoDolar = valor;

	@Override
	double calculaValor() {
		double total = +valor ; 
		//admitimos a conversao de 1 dolar = 5 reais
		return total;
	}

	@Override
	public String toString() {
		return "Dolar [converter=" + valor*5 + "]";
	}

	
}
