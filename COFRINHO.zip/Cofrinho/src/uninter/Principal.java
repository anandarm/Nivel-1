package uninter;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
			Scanner teclado = new Scanner(System.in);
			int opcao; 	
			
			Cofre cofre = new Cofre();
			
			System.out.println("Bem vindo ao poupa tempo, selecione opcao desejada: ");
			System.out.println("1-Poupar"); //opcao atende a exigencia adicionar moedas
			System.out.println("2-Sacar"); //opcao atende a exigencia remover moedas
			System.out.println("3-Listar moedas"); //opcao atende a exigencia listar moedas
			System.out.println("4-Consultar saldo em reais"); //opcao atende a exigencia consulta saldo convertido em reais
			System.out.println("5-Encerrar sessao");
			opcao=teclado.nextInt();
			
			int cambio;
			double valor;
			double converter = 0;
			Moeda mod;
		
			while(opcao!=5) {
		
					switch(opcao) {
		
					case 1: //aqui temos o submenu com as opções de cambio para adicionar moedas ao cofre
			
							//cambio=0;// para este bloco temos apenas o submenu com as opções para o usuário, declarado valor nulo para variável cambio
							cambio=0;
							while(cambio<0 || cambio>=3) { //condições apresentadas de acordo com tipos de moeda submenu
			
			//nesta parte do bloco perguntamos ao usuário sobre qual moeda cambio irá incidir ação de adicionar moeda ao cofre
							System.out.println("Qual moeda irá poupar?");
							System.out.println("1-Euro");
							System.out.println("2-Dolar");
							System.out.println("3-Real");
							cambio = teclado.nextInt();//entrada de dados pelo usuario tipo de cambio
							}
							System.out.println("Qual valor a ser poupado?");
							valor = teclado.nextDouble();
							//nesta parte do bloco contem todas as veriaveis declaradas na classe abstrada moeda
							mod=null;
							if(cambio==1) {
								mod=new Euro(cambio,valor, converter);
								System.out.println("Euro adicionado ao cofre com sucesso");
							}
							if (cambio==2) {
								mod=new Dolar(cambio,valor,converter);
								System.out.println("Dolar adicionado ao cofre com sucesso");
							}
							else {
								mod=new Real(cambio,valor,converter);
								System.out.println("Real adicionado ao cofre com suceso");
							}
							
								cofre.adicionar(mod);
					
								break;
				
					case 2:
			
							cambio=0;// para este bloco contido na chave temos apenas o submenu com as opções para o usuário, declarado valor nulo para variável cambio
							while(cambio<0 || cambio>3) { //condições apresentadas de acordo com tipos de moeda submenu
				
				//nesta parte do bloco perguntamos ao usuário sobre qual moeda cambio irá incidir ação de remover moeda ao cofre
									System.out.println("Qual moeda irá sacar?");
									System.out.println("1-Euro");
									System.out.println("2-Dolar");
									System.out.println("3-Real");
									cambio=teclado.nextInt();//entrada de dados pelo usuario tipo de cambio
							}
							System.out.println("Qual valor a ser sacado?");
							valor = teclado.nextDouble();
							mod=null;
							if(cambio==1) {
								//nesta parte do bloco perguntamos ao usuário sobre qual valor irá ser removido do cofre
								mod = new Euro (cambio,valor,converter);
								System.out.println("Euro sacado com sucesso");
							}
								if (cambio==2) {
						//nesta parte do bloco perguntamos ao usuário sobre qual valor irá ser removido do cofre
									mod = new Dolar(cambio, valor, converter);
									System.out.println("Dolar sacado com sucesso");
								}
								else {
							//nesta parte do bloco perguntamos ao usuário sobre qual valor irá ser removido do cofre
										mod = new Real(cambio,valor,converter);
										System.out.println("Real sacado com suceso");
								}
								cofre.remover(mod);
				
								break;				
								
						case 3: 
			
								cofre.listar();
								break;
						default:
							System.out.println("Opcao invalida!");
			//excecao para opcao 3 listar
			
					}
					
					System.out.println("Bem vindo ao poupa tempo, selecione opcao desejada: ");
					System.out.println("1-Poupar"); //opcao atende a exigencia adicionar moedas
					System.out.println("2-Sacar"); //opcao atende a exigencia remover moedas
					System.out.println("3-Listar moedas"); //opcao atende a exigencia listar moedas
					System.out.println("4-Consultar saldo em reais"); //opcao atende a exigencia consulta saldo convertido em reais
					System.out.println("5-Encerrar sessao");
					opcao=teclado.nextInt();
		
				}
		}
}


		


			
		




		