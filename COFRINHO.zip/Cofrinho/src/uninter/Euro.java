package uninter;

public class Euro extends Moeda {

	double converter;

	public Euro(int cambio, double valor, double converter) {
		super(cambio, valor);
		this.converter = converter;
	}
	
	double saldoEuro = valor;

	@Override
	double calculaValor() {
		double total = + valor;
		// realiza somatorio em reais do total euros armazenado em euro
		return total;
	}

	@Override
	public String toString() {
		return "Euro [converter=" + valor*6 + "]";
	}

	
}
